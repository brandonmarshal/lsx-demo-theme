<?php

namespace Fishing_CPT;

if (! defined('ABSPATH')) {
	exit;
}

/**
 * Register custom block types and bindings.
 */
function register_blocks(): void
{
	$folders = ['fish-card', 'gear-card', 'story-card', 'repeatable-facts'];
	foreach ($folders as $folder) {
		$path = FISHING_CPT_PLUGIN_DIR . 'blocks/' . $folder;
		if (file_exists($path . '/block.json')) {
			\register_block_type($path);
		}
	}
	if (function_exists('register_block_bindings_source')) {
		\register_block_bindings_source('fishing/fish-facts', [
			'label'     => \__('Fish Facts', 'fishing-cpt-plugin'),
			'get_value' => function ($attributes, $context) {
				$post_id = isset($context['postId']) ? (int) $context['postId'] : 0;
				if (! $post_id) {
					return '';
				}
				$json  = \get_post_meta($post_id, 'fish_facts', true);
				$facts = json_decode($json, true);
				if (empty($facts)) {
					return '';
				}
				return \wp_json_encode(array_map('sanitize_text_field', $facts));
			},
		]);
	}
}
\add_action('init', __NAMESPACE__ . '\register_blocks');
